export class Department {
  constructor(public DeptNo:number, public DeptName:string){}
}

export const Categories:Array<Department> = new Array<Department>();
Categories.push(new Department(10, 'ECT'));
Categories.push(new Department(20, 'ECL'));
Categories.push(new Department(30, 'Food'));

export class Employee {
  constructor(public EmpNo:number, public EmpName:string, public DeptNo:number){}
}

export const Products:Array<Employee> = new Array<Employee>();
Products.push(new Employee(101, 'Mobile', 10));
Products.push(new Employee(102, 'Laptop', 20));
Products.push(new Employee(103, 'TV', 30));
Products.push(new Employee(104, 'Washingmachine', 10));
Products.push(new Employee(105, 'burger', 20));
Products.push(new Employee(106, 'F', 30));
