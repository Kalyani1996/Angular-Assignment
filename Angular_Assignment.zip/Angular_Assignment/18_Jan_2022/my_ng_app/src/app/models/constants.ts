export const Categories = ['Electronics', 'Electrical', 'Food', 'Fashion'];
export const Manufacturers  = ['MS-ECT', 'MS-ECL', 'MS-Food', 'MS-Fashion','LS-ECT', 'LS-ECL', 'LS-Food', 'LS-Fashion'];

