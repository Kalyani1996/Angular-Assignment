;
const express=require("express");
const student = require("./models/student")
const app=express();
require("./database/conn")
const port=process.env.PORT || 3000;
const router = require("./router/studentdata")

app.use(express.json());

app.get("/",(req,res)=>

{
    
    res.send("Hello from get api");
})

// app.post("/students",(req,res)=>
// {
//     const user  = new student(req.body);
//     console.log("body-------------",user);
//     user.save()
//     .then(()=>{
//         res.status(200).send(user);
//     })
//     .catch((err)=>{
//         res.status(400).send(err);
//     })

//    res.send("Hello from post api");
// })

app.get("/getstudents",async(req,res)=>
{   
    try{
        const data = await student.find();
        res.status(200).send(data);
    }catch(err){    
        res.status(400).send(err);
    }
    

});

app.post("/students",async(req,res)=>
{   
    try{
        const user  = new student(req.body);
        const data = await user.save();
        res.status(200).send(data);
    }catch(err){    
        res.status(400).send(err);
    }
});

app.get("/getstudents:id",async(req,res)=>
{   
    try{
        const _id  = req.params.id;
        console.log(user);
        const studdata = student.findById({_id});
        console.log(studdata);

        res.status(200).send(studdata);
    }catch(err){    
        res.status(400).send(err);
    }
});

// app.delete("/deletestudentdata/:id",async(req,res)=>{
//     console.log(req);

// try
// {
//     // const _id  = req.params.id;
//     const studdata = await student.findByIdAndDelete(req.params.id);
//     console.log(studdata);
//     if(!req.params.id){
//         return res.status(400).send();
//     }
//      res.send(studdata);

// }catch(err)
// {
//     res.status(500).send(err);

// }
// });
app.delete("/students/:id", async(req, res)=>{

    try{

        // const _id=req.params.id

        const dstuddata= await student.findByIdAndDelete(req.params.id);

        if(!req.params.id){

            return res.status(400).send();

        }

        res.send(dstuddata);

    }catch(e){

        res.status(500).send(e)

        console.log(e);

    }

    })  


app.patch("/studentsupdate/:id",async(req,res)=>{
try{
        const _id=req.params.id
        const ddstuddata= await student.findByIdAndUpdate(_id,req.body);
        res.send(ddstuddata);


}catch(err){
    res.status(500).send(err)

}
})
app.put("/studentsupdate/:id",async(req,res)=>{
    try{
            const _id=req.params.id
            const ddstuddata= await student.findByIdAndUpdate(_id,req.body);
            res.send(ddstuddata);
    
    
    }catch(err){
        res.status(500).send(err)
    
    }
    })


    const router1 = new express.Router();
    router1.patch("/student/:id",async(req,res)=>{
        try{
                res.send("welcome to router");
        
        
        }catch(err){
            res.status(500).send(err)
        
        }
        })
        app.use(router);

app.listen(port,()=>{

    console.log(`connection is setup at ${port}`);

});